#include <iostream>

#include "cliente.h"
#include "cuarto.h"
#include "empleado.h"
#include "persona.h"


void CrearCliente();
void CrearEmpleado();
void CrearCuarto();
void MostrarCliente();
void MostrarEmpleado();
void MostrarCuarto();

